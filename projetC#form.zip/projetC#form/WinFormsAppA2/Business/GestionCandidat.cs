﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WinFormsAppA2.Models;
using WinFormsAppA2.Services;

namespace WinFormsAppA2.Business
{
    class GestionCandidat : InterfaceGestionCandidat
    {
        static List<Candidat> candidats=new List<Candidat>();
        public void AjouterCandidat(Candidat candidat)
        {
            candidats.Add(candidat);
        }

        public List<Candidat> ListCandidats()
        {
            return candidats;
        }

        public void ModifierCandidat(Candidat candidat, Candidat nouveauCandidat)
        {
            Candidat candidatAModifier = rechercherCandidat(candidat.Nom, candidat.Prenom);

            candidatAModifier.Nom = nouveauCandidat.Nom;
            candidatAModifier.Prenom = nouveauCandidat.Prenom;
            candidatAModifier.DateNaissance = nouveauCandidat.DateNaissance;
            candidatAModifier.Description = nouveauCandidat.Description;
            candidatAModifier.DiplomeCandidat = nouveauCandidat.DiplomeCandidat;
            candidatAModifier.GenreCandidat = nouveauCandidat.GenreCandidat;
            candidatAModifier.LoisirsCandidat = nouveauCandidat.LoisirsCandidat;
            candidatAModifier.AutreLoisir = nouveauCandidat.AutreLoisir;
        }

        public Candidat rechercherCandidat(string nom, string prenom)
        {
            foreach (var item in candidats)
            {
                if (item.Nom == nom && item.Prenom == prenom)
                    return item;
            }
            return null;
        }

        public void SupprimerCandidat(Candidat candidat)
        {
            candidats.Remove(candidat);
        }

        public void SupprimerCandidat(string nom, string prenom)
        {
            Candidat candidat = rechercherCandidat(nom, prenom);
            if (candidat!=null)
                SupprimerCandidat(candidat);
        }
    }
}
