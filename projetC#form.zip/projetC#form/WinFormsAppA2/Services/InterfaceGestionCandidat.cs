﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WinFormsAppA2.Models;

namespace WinFormsAppA2.Services
{
    interface InterfaceGestionCandidat
    {
        void AjouterCandidat(Candidat candidat);
        void ModifierCandidat(Candidat candidat, Candidat nouveauCandidat);
        Candidat rechercherCandidat(string nom, string prenom);
        void SupprimerCandidat(Candidat candidat);
        void SupprimerCandidat(string nom, string prenom);
        List<Candidat> ListCandidats();
    }
}
