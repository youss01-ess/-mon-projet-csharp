﻿namespace WinFormsAppA2.Models
{
    internal enum Loisir
    {
        sport, musique, cinéma, autre
    }
}