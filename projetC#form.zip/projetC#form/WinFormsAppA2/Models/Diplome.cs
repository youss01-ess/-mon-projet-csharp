﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsAppA2.Models
{
    enum Diplome
    {
        bac, bac2, bac3, bac5, licence, 
        master, ingénieur, doctorat
    }
}
