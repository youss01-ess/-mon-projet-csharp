﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace WinFormsAppA2.Models
{
    class Candidat
    {
        string nom;
        string prenom;
        DateTime dateNaissance;
        string description;
        Diplome diplomeCandidat;
        Genre genreCandidat;
        List<Loisir> loisirsCandidat;
        string autreLoisir;
        Image photo;

        public Candidat()
        {
            loisirsCandidat = new List<Loisir>();
            nom=prenom=description=autreLoisir = "?????";
            dateNaissance = new DateTime(1980,1,1);
            diplomeCandidat = Diplome.bac;
            genreCandidat = Genre.Masculin;
        }
        public void AjouterLoisir(Loisir loisir)
        {
            loisirsCandidat.Add(loisir);
        }
        public void SupprimerLoisir(Loisir loisir)
        {
            loisirsCandidat.Remove(loisir);
        }
        public string Nom { get => nom; set => nom = value; }
        public string Prenom { get => prenom; set => prenom = value; }
        public DateTime DateNaissance { get => dateNaissance; set => dateNaissance = value; }
        public string Description { get => description; set => description = value; }
        public string AutreLoisir { get => autreLoisir; set => autreLoisir = value; }
        internal Diplome DiplomeCandidat { get => diplomeCandidat; set => diplomeCandidat = value; }
        internal Genre GenreCandidat { get => genreCandidat; set => genreCandidat = value; }
        internal List<Loisir> LoisirsCandidat { get => loisirsCandidat; set => loisirsCandidat = value; }
        public Image Photo { get => photo; set => photo = value; }
    }
}
