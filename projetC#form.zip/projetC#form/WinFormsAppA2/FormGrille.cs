﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsAppA2.Business;
using WinFormsAppA2.Models;
using WinFormsAppA2.Services;

namespace WinFormsAppA2
{
    public partial class FormGrille : Form
    {

        InterfaceGestionCandidat gestion;
        public FormGrille()
        {
            InitializeComponent();
            gestion= new GestionCandidat();
        }

        private void FormGrille_Load(object sender, EventArgs e)
        {

            List<Candidat> liste = gestion.ListCandidats();
            
            dataGridView1.DataSource = liste;
        }
    }
}
