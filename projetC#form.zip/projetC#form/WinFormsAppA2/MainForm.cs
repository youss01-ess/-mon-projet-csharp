﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsAppA2.Business;
using WinFormsAppA2.Models;
using WinFormsAppA2.Services;
using static System.Collections.Specialized.BitVector32;

namespace WinFormsAppA2
{
    public partial class MainForm : Form
    {
        InterfaceGestionCandidat gestion;
        public MainForm()
        {
            InitializeComponent();
            gestion = new GestionCandidat();
        }

        private void ajouterUnCandidatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.ShowDialog();
        }

        private void listerLesCandidatsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void quitterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void listageParFormulaireToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
            List<Candidat> candidats = gestion.ListCandidats();
            if (candidats.Count == 0)
            {
                MessageBox.Show("Aucun candidat n'est enregistré",
                    "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            FormListage form = new FormListage();
            form.ShowDialog();
        }

        private void listageParGrilleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormGrille form=new FormGrille();
            form.ShowDialog();
        }
    }
}
