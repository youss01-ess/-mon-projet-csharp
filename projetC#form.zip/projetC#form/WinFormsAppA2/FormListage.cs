﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsAppA2.Business;
using WinFormsAppA2.Models;
using WinFormsAppA2.Services;

namespace WinFormsAppA2
{
    public partial class FormListage : Form
    {
        int index = 0;
        InterfaceGestionCandidat gestion;
        public FormListage()
        {
            InitializeComponent();
            gestion = new GestionCandidat();
        }

        private void FormListage_Load(object sender, EventArgs e)
        {
           
            List<Candidat> candidats = gestion.ListCandidats();
            index = 0;
            Candidat candidat = candidats[index];
            textBox1.Text = candidat.Nom;
            textBox2.Text = candidat.Prenom;
            pictureBox1.Image= candidat.Photo;
            textBox3.Text = candidat.Description;
            textBox4.Text = candidat.GenreCandidat.ToString();
            textBox5.Text = candidat.DateNaissance.ToShortDateString();
            textBox6.Text = candidat.DiplomeCandidat.ToString();
            listBox1.Items.Clear();
            foreach (var item in candidat.LoisirsCandidat)
            {
                if(item== Loisir.autre)
                {
                    listBox1.Items.Add(candidat.AutreLoisir);
                }
                else               
                    listBox1.Items.Add(item.ToString());
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {

            List<Candidat> candidats = gestion.ListCandidats();
            index++;
            if (index >= candidats.Count)
            {
                index = candidats.Count - 1;
            }
            Candidat candidat = candidats[index];
            textBox1.Text = candidat.Nom;
            textBox2.Text = candidat.Prenom;
            pictureBox1.Image = candidat.Photo;
            textBox3.Text = candidat.Description;
            textBox4.Text = candidat.GenreCandidat.ToString();
            textBox5.Text = candidat.DateNaissance.ToShortDateString();
            textBox6.Text = candidat.DiplomeCandidat.ToString();
            listBox1.Items.Clear();
            foreach (var item in candidat.LoisirsCandidat)
            {
                if (item == Loisir.autre)
                {
                    listBox1.Items.Add(candidat.AutreLoisir);
                }
                else
                    listBox1.Items.Add(item.ToString());
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {

            List<Candidat> candidats = gestion.ListCandidats();
            index--;
            if (index < 0)
            {
                index = 0;
            }
            Candidat candidat = candidats[index];
            textBox1.Text = candidat.Nom;
            textBox2.Text = candidat.Prenom;
            pictureBox1.Image = candidat.Photo;
            textBox3.Text = candidat.Description;
            textBox4.Text = candidat.GenreCandidat.ToString();
            textBox5.Text = candidat.DateNaissance.ToShortDateString();
            textBox6.Text = candidat.DiplomeCandidat.ToString();
            listBox1.Items.Clear();
            foreach (var item in candidat.LoisirsCandidat)
            {
                if (item == Loisir.autre)
                {
                    listBox1.Items.Add(candidat.AutreLoisir);
                }
                else
                    listBox1.Items.Add(item.ToString());
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {

            List<Candidat> candidats = gestion.ListCandidats();
            index=candidats.Count-1;

            Candidat candidat = candidats[index];
            textBox1.Text = candidat.Nom;
            textBox2.Text = candidat.Prenom;
            pictureBox1.Image = candidat.Photo;
            textBox3.Text = candidat.Description;
            textBox4.Text = candidat.GenreCandidat.ToString();
            textBox5.Text = candidat.DateNaissance.ToShortDateString();
            textBox6.Text = candidat.DiplomeCandidat.ToString();
            listBox1.Items.Clear();
            foreach (var item in candidat.LoisirsCandidat)
            {
                if (item == Loisir.autre)
                {
                    listBox1.Items.Add(candidat.AutreLoisir);
                }
                else
                    listBox1.Items.Add(item.ToString());
            }
        }
    }
}
