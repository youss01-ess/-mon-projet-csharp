using WinFormsAppA2.Business;
using WinFormsAppA2.Models;
using WinFormsAppA2.Services;

namespace WinFormsAppA2
{
    public partial class Form1 : Form
    {
        InterfaceGestionCandidat gestion;
        public Form1()
        {
            InitializeComponent();
            gestion = new GestionCandidat();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Candidat candidat = new Candidat();
            candidat.Nom = textBox1.Text;
            candidat.Prenom = textBox2.Text;
            candidat.Photo = pictureBox1.Image;
            candidat.DateNaissance = DateTime.Parse(dateTimePicker1.Text);
            candidat.Description = textBox3.Text;
            candidat.DiplomeCandidat = Enum.Parse<Diplome>(comboBox1.Text);
            if (radioButton1.Checked)
                candidat.GenreCandidat = Genre.Masculin;
            else
                candidat.GenreCandidat = Genre.F�minin;
            if (checkBox1.Checked)
                candidat.AjouterLoisir(Loisir.sport);
            if (checkBox2.Checked)
                candidat.AjouterLoisir(Loisir.cin�ma);
            if (checkBox3.Checked)
                candidat.AjouterLoisir(Loisir.musique);

            if (checkBox4.Checked)
            {
                candidat.AjouterLoisir(Loisir.autre);
                candidat.AutreLoisir = textBox4.Text;
            }

            
            gestion.AjouterCandidat(candidat);
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Image Files|*.jpg;*.gif;*.bmp;*.png";
            openFileDialog1.ShowDialog();
            string filename=openFileDialog1.FileName;
            //MessageBox.Show(filename);
            pictureBox1.Image=Image.FromFile(filename);
        }
    }
}
