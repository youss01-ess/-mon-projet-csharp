﻿namespace WinFormsAppA2
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            candidatsToolStripMenuItem = new ToolStripMenuItem();
            ajouterUnCandidatToolStripMenuItem = new ToolStripMenuItem();
            listerLesCandidatsToolStripMenuItem = new ToolStripMenuItem();
            listageParFormulaireToolStripMenuItem = new ToolStripMenuItem();
            listageParGrilleToolStripMenuItem = new ToolStripMenuItem();
            toolStripMenuItem1 = new ToolStripSeparator();
            quitterToolStripMenuItem = new ToolStripMenuItem();
            helpToolStripMenuItem = new ToolStripMenuItem();
            aProosDeToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { candidatsToolStripMenuItem, helpToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // candidatsToolStripMenuItem
            // 
            candidatsToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { ajouterUnCandidatToolStripMenuItem, listerLesCandidatsToolStripMenuItem, toolStripMenuItem1, quitterToolStripMenuItem });
            candidatsToolStripMenuItem.Name = "candidatsToolStripMenuItem";
            candidatsToolStripMenuItem.Size = new Size(72, 20);
            candidatsToolStripMenuItem.Text = "Candidats";
            // 
            // ajouterUnCandidatToolStripMenuItem
            // 
            ajouterUnCandidatToolStripMenuItem.Image = Properties.Resources.Add_Symbol_icon;
            ajouterUnCandidatToolStripMenuItem.Name = "ajouterUnCandidatToolStripMenuItem";
            ajouterUnCandidatToolStripMenuItem.Size = new Size(180, 22);
            ajouterUnCandidatToolStripMenuItem.Text = "Ajouter un candidat";
            ajouterUnCandidatToolStripMenuItem.Click += ajouterUnCandidatToolStripMenuItem_Click;
            // 
            // listerLesCandidatsToolStripMenuItem
            // 
            listerLesCandidatsToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { listageParFormulaireToolStripMenuItem, listageParGrilleToolStripMenuItem });
            listerLesCandidatsToolStripMenuItem.Image = Properties.Resources.form_icon;
            listerLesCandidatsToolStripMenuItem.Name = "listerLesCandidatsToolStripMenuItem";
            listerLesCandidatsToolStripMenuItem.Size = new Size(180, 22);
            listerLesCandidatsToolStripMenuItem.Text = "Lister les candidats";
            listerLesCandidatsToolStripMenuItem.Click += listerLesCandidatsToolStripMenuItem_Click;
            // 
            // listageParFormulaireToolStripMenuItem
            // 
            listageParFormulaireToolStripMenuItem.Image = Properties.Resources.application_form_icon;
            listageParFormulaireToolStripMenuItem.Name = "listageParFormulaireToolStripMenuItem";
            listageParFormulaireToolStripMenuItem.Size = new Size(189, 22);
            listageParFormulaireToolStripMenuItem.Text = "Listage par formulaire";
            listageParFormulaireToolStripMenuItem.Click += listageParFormulaireToolStripMenuItem_Click;
            // 
            // listageParGrilleToolStripMenuItem
            // 
            listageParGrilleToolStripMenuItem.Image = Properties.Resources.File_Table_icon;
            listageParGrilleToolStripMenuItem.Name = "listageParGrilleToolStripMenuItem";
            listageParGrilleToolStripMenuItem.Size = new Size(189, 22);
            listageParGrilleToolStripMenuItem.Text = "Listage par grille";
            listageParGrilleToolStripMenuItem.Click += listageParGrilleToolStripMenuItem_Click;
            // 
            // toolStripMenuItem1
            // 
            toolStripMenuItem1.Name = "toolStripMenuItem1";
            toolStripMenuItem1.Size = new Size(177, 6);
            // 
            // quitterToolStripMenuItem
            // 
            quitterToolStripMenuItem.Name = "quitterToolStripMenuItem";
            quitterToolStripMenuItem.Size = new Size(180, 22);
            quitterToolStripMenuItem.Text = "Quitter";
            quitterToolStripMenuItem.Click += quitterToolStripMenuItem_Click;
            // 
            // helpToolStripMenuItem
            // 
            helpToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { aProosDeToolStripMenuItem });
            helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            helpToolStripMenuItem.Size = new Size(44, 20);
            helpToolStripMenuItem.Text = "Help";
            // 
            // aProosDeToolStripMenuItem
            // 
            aProosDeToolStripMenuItem.Name = "aProosDeToolStripMenuItem";
            aProosDeToolStripMenuItem.Size = new Size(140, 22);
            aProosDeToolStripMenuItem.Text = "A proos de...";
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.esisa;
            BackgroundImageLayout = ImageLayout.Zoom;
            ClientSize = new Size(800, 450);
            Controls.Add(menuStrip1);
            DoubleBuffered = true;
            MainMenuStrip = menuStrip1;
            Name = "MainForm";
            Text = "Gestion des candidats";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem candidatsToolStripMenuItem;
        private ToolStripMenuItem ajouterUnCandidatToolStripMenuItem;
        private ToolStripMenuItem listerLesCandidatsToolStripMenuItem;
        private ToolStripSeparator toolStripMenuItem1;
        private ToolStripMenuItem quitterToolStripMenuItem;
        private ToolStripMenuItem helpToolStripMenuItem;
        private ToolStripMenuItem aProosDeToolStripMenuItem;
        private ToolStripMenuItem listageParFormulaireToolStripMenuItem;
        private ToolStripMenuItem listageParGrilleToolStripMenuItem;
    }
}